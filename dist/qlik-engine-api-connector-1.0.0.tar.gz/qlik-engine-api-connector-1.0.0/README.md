# qlik-engine-api-connector
Web-socket connector for Qlik engine API. 
